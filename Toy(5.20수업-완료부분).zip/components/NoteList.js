import React, { useState } from "react";
import { View, Text, StyleSheet, Pressable, FlatList } from "react-native";
import DrawMain from "../Screens/DrawMain";
import ViewNote from "../Screens/ViewNote";

const NoteList = ({navigation, items}) => {


  return (
    <View style={styles.textStyle}>
      <Text>NoteList</Text>
      <FlatList
        data={items}
        renderItem={({item}) => <Pressable onPress={()=> navigation.push("ViewNote")}><Text>{item.title}</Text></Pressable> }
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  buttonStyle: {
    alignItems: "center",
    justifyContent: "center",
    width: 120,
    position: "absolute",
    top: 550,
    right: 20,
    height: 40,
    backgroundColor: "#AE8B59",
    borderRadius: 100
  },
  textStyle: {
    fontSize: 13,
    color: "white"
  }
});



//노트에 저장한 데이터 가져오기, 저장데이터 드로우메인에 표시(연결)하기

export default NoteList;
