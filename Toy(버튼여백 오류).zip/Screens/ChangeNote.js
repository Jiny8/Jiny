import React from 'react';
import { View, Text, Button,Touchable,Pressable,StyleSheet } from 'react-native';


function ChangeNote({navigation}) {
    return(
        <View>
            <Text>ChangeNote (수정페이지)</Text>

            <Button title='처음으로(메인화면)'
            onPress={()=> navigation.popToTop()}/>
        </View>
      
    )
  }
  // 저장된 데이터를 수정할 수 있는 페이지입니다.
  export default ChangeNote;