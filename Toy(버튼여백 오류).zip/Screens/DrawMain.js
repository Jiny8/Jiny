import React, { useState } from 'react';
import { View, Text, Button, Touchable,Pressable,StyleSheet } from 'react-native';
import CreateButton from "../components/CreateButton";
import Search from "../components/Search";
import Title from "../components/Title";
import NoteList from '../components/NoteList';

function DrawMain({navigation}) {
    const [items, setItems] = useState([
        { id: 1, title: "230517", contents: "ㅎㅎ" },
        { id: 2, title: "글제목입니다", contents: "할수있다" },
        { id: 3, title: "안녕하세요", contents: "네?" }
      ]);
      
    return(
        <View>
            <Title />
            <Search />
            <NoteList navigation={navigation} items={items} />
            <CreateButton  navigation={navigation} />
        </View>
    )
}
  
  
export default DrawMain;