import React from 'react';
import { View, Text, Button,Touchable,Pressable,StyleSheet } from 'react-native';


function ViewNote({navigation}) {
    return(
        <View>
            <Text>선택한 노트 보기.</Text>

            <Button title='처음으로(메인화면)'
            onPress={()=> navigation.popToTop()}/>
        </View>
      
    )
  }
  // 선택한 데이터를 볼 수 있는 페이지입니다.
  export default ViewNote;