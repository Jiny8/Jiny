import React from 'react';
import { View, Text, Button,Touchable,Pressable,StyleSheet } from 'react-native';


function CreateNote({route, navigation}) {
    return(
        <View>
            {console.log(route)}
            <Text>새 노트를 작성해주세요.</Text>
            <Text>넘겨받는 번호: {route.params.num}</Text>
            <Button title='새 노트 만들기(CreateNote)'
            onPress={()=> navigation.push('CreateNote', {num: route.params.num+1})}/>
            <Button title='뒤로가기(현재 페이지 빠져나오기)'
            onPress={()=> navigation.pop()}/>
            <Button title='처음으로(메인화면)'
            onPress={()=> navigation.popToTop()}/>
        </View>
      
    )
  }
  //고유번호를 부여하여  선택한 고유페이지번호를 불러올수있도록할것, 버튼은 주로 프레셔블을 사용함,
  export default CreateNote;